
package Main;
public class AgregarConsultar {
 private char agregarConsultar;

    public char getAgregarConsultar() {
        return agregarConsultar;
    }

    public void setAgregarConsultar(char agregarConsultar) {
        this.agregarConsultar = agregarConsultar;
    }
 
}
