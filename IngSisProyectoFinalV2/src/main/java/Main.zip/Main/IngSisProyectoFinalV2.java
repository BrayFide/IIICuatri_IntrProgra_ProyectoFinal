/*
    Proyecto Introducción a la Programación
    III Cuatrimestre
    Estudiantes:
    Brayton Maccoy Artola
    Jean Paulo Monge Alfaro
    Jeremy Acuña Brenes

    Profesor: Esteban Marín Chinchilla
*/
package Main;

public class IngSisProyectoFinalV2 {
    
    public static void main(String[] args) {
        
     Menu r=new Menu();
     r.mostrarMenu();
     
   
    }
}